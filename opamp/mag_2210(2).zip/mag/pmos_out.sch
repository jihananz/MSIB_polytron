v {xschem version=3.4.6RC file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
N 2540 -730 2540 -710 {lab=D5}
N 2540 -730 2630 -730 {lab=D5}
N 2630 -730 2740 -730 {lab=D5}
N 2740 -730 2740 -710 {lab=D5}
N 2720 -680 2740 -680 {lab=VDD}
N 2470 -680 2500 -680 {lab=VIN}
N 2780 -680 2810 -680 {lab=VIP}
N 2540 -680 2610 -680 {lab=VDD}
N 2540 -650 2540 -620 {lab=D8}
N 2610 -680 2630 -680 {lab=VDD}
N 2630 -710 2630 -680 {lab=VDD}
N 2630 -680 2720 -680 {lab=VDD}
N 2740 -650 2740 -620 {lab=OUT}
N 2740 -730 2810 -730 {lab=D5}
N 2740 -620 2810 -620 {lab=OUT}
N 2720 -580 2780 -580 {lab=D5}
N 2780 -580 2780 -520 {lab=D5}
N 2720 -520 2780 -520 {lab=D5}
N 2760 -550 2780 -550 {lab=D5}
N 2640 -570 2640 -550 {lab=VDD}
N 2920 -530 2980 -530 {lab=D8}
N 2960 -560 2980 -560 {lab=D8}
N 2720 -420 2780 -420 {lab=OUT}
N 2760 -450 2780 -450 {lab=OUT}
N 2840 -580 2840 -560 {lab=VDD}
N 2640 -470 2640 -450 {lab=VDD}
N 2960 -440 3020 -440 {lab=D8}
N 3000 -470 3020 -470 {lab=D8}
N 2880 -490 2880 -470 {lab=VDD}
N 2750 -340 2810 -340 {lab=OUT}
N 2790 -370 2810 -370 {lab=OUT}
N 2720 -480 2780 -480 {lab=OUT}
N 2780 -480 2780 -420 {lab=OUT}
N 2750 -400 2810 -400 {lab=OUT}
N 2810 -400 2810 -340 {lab=OUT}
N 2840 -560 2920 -560 {lab=VDD}
N 2920 -590 2980 -590 {lab=D8}
N 2980 -590 2980 -530 {lab=D8}
N 2880 -470 2960 -470 {lab=VDD}
N 2960 -500 3020 -500 {lab=D8}
N 3020 -500 3020 -440 {lab=D8}
N 2670 -390 2670 -370 {lab=VDD}
N 2670 -370 2750 -370 {lab=VDD}
N 2640 -450 2720 -450 {lab=VDD}
N 2640 -550 2720 -550 {lab=VDD}
C {sky130_fd_pr/pfet_01v8.sym} 2520 -680 0 0 {name=M6
L=0.5
W=1
nf=1
mult=4
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {sky130_fd_pr/pfet_01v8.sym} 2760 -680 0 1 {name=M7
L=0.5
W=1
nf=1
mult=4
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {devices/ipin.sym} 2810 -680 2 0 {name=p4 lab=VIP}
C {devices/ipin.sym} 2470 -680 0 0 {name=p5 lab=VIN}
C {devices/iopin.sym} 2540 -620 0 0 {name=p1 lab=D8}
C {devices/iopin.sym} 2810 -730 0 0 {name=p3 lab=D5}
C {devices/iopin.sym} 2630 -710 0 0 {name=p6 lab=VDD}
C {devices/opin.sym} 2810 -620 0 0 {name=p2 lab=OUT}
C {sky130_fd_pr/pfet_01v8.sym} 2740 -550 0 1 {name=M1
L=0.5
W=1
nf=1
mult=4
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {devices/iopin.sym} 2780 -580 0 0 {name=p7 lab=D5}
C {devices/iopin.sym} 2640 -570 0 0 {name=p8 lab=VDD}
C {sky130_fd_pr/pfet_01v8.sym} 2940 -560 0 1 {name=M2
L=0.5
W=1
nf=1
mult=2
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {devices/iopin.sym} 2980 -590 0 0 {name=p9 lab=D8}
C {sky130_fd_pr/pfet_01v8.sym} 2740 -450 0 1 {name=M3
L=0.5
W=1
nf=1
mult=2
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {devices/opin.sym} 2780 -480 0 0 {name=p10 lab=OUT}
C {devices/iopin.sym} 2840 -580 0 0 {name=p11 lab=VDD}
C {devices/iopin.sym} 2640 -470 0 0 {name=p12 lab=VDD}
C {sky130_fd_pr/pfet_01v8.sym} 2980 -470 0 1 {name=M4
L=0.15
W=1
nf=1
mult=4
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {devices/iopin.sym} 3020 -500 0 0 {name=p13 lab=D8}
C {devices/iopin.sym} 2880 -490 0 0 {name=p14 lab=VDD}
C {sky130_fd_pr/pfet_01v8.sym} 2770 -370 0 1 {name=M5
L=0.15
W=1
nf=1
mult=4
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {devices/opin.sym} 2810 -400 0 0 {name=p15 lab=OUT
L=0.15
mult=4}
C {devices/iopin.sym} 2670 -390 0 0 {name=p16 lab=VDD
L=0.15
mult=4}
