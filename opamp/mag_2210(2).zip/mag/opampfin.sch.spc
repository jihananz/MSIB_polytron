** sch_path: /home/jihananz/project/mag/opampfin.sch
.subckt opampfin VDD VIP VIN RS GND OUT D1 D2 D5 D8
*.PININFO VDD:B VIP:I VIN:I RS:B GND:B OUT:O D1:B D2:B D5:B D8:B
x1 VDD D5 D1 D2 pmos_cs
x3 D2 D1 RS GND nmosdp
x4 D8 OUT GND nmoscs2
x2 D5 VDD VIP VIN OUT D8 pmos_out2
.ends

* expanding   symbol:  pmos_cs.sym # of pins=4
** sym_path: /home/jihananz/project/mag/pmos_cs.sym
** sch_path: /home/jihananz/project/mag/pmos_cs.sch
.subckt pmos_cs VDD D5 D1 D2
*.PININFO VDD:B D5:B D2:B D1:B
XM2 D2 D2 VDD VDD sky130_fd_pr__pfet_01v8 L=1 W=2 nf=1 m=2
XM1 D1 D2 VDD VDD sky130_fd_pr__pfet_01v8 L=1 W=2 nf=1 m=2
XM5 D5 D2 VDD VDD sky130_fd_pr__pfet_01v8 L=1 W=2 nf=1 m=2
XM3 D5 D5 D5 VDD sky130_fd_pr__pfet_01v8 L=0.15 W=2 nf=1 m=2
XM4 VDD VDD VDD VDD sky130_fd_pr__pfet_01v8 L=1 W=2 nf=1 m=2
XM6 D2 D2 D2 VDD sky130_fd_pr__pfet_01v8 L=0.15 W=2 nf=1 m=2
XM7 D1 D1 D1 VDD sky130_fd_pr__pfet_01v8 L=0.15 W=2 nf=1 m=2
XM8 VDD VDD VDD VDD sky130_fd_pr__pfet_01v8 L=0.15 W=2 nf=1 m=2
.ends


* expanding   symbol:  nmosdp.sym # of pins=4
** sym_path: /home/jihananz/project/mag/nmosdp.sym
** sch_path: /home/jihananz/project/mag/nmosdp.sch
.subckt nmosdp D4 D1 RS GND
*.PININFO D1:B D4:B GND:B RS:B
XM3 D1 D1 GND GND sky130_fd_pr__nfet_01v8 L=1 W=2 nf=1 m=2
XM4 D4 D1 RS GND sky130_fd_pr__nfet_01v8 L=1 W=2 nf=1 m=2
XM1 D1 D1 D1 GND sky130_fd_pr__nfet_01v8 L=0.15 W=2 nf=1 m=2
XM2 D4 D4 D4 GND sky130_fd_pr__nfet_01v8 L=0.15 W=2 nf=1 m=2
.ends


* expanding   symbol:  nmoscs2.sym # of pins=3
** sym_path: /home/jihananz/project/mag/nmoscs2.sym
** sch_path: /home/jihananz/project/mag/nmoscs2.sch
.subckt nmoscs2 D8 D9 GND
*.PININFO GND:B D9:B D8:B
XM9 D9 D8 GND GND sky130_fd_pr__nfet_01v8 L=0.8 W=1 nf=1 m=4
XM8 D8 D8 GND GND sky130_fd_pr__nfet_01v8 L=0.8 W=1 nf=1 m=4
XM1 D8 D8 D8 GND sky130_fd_pr__nfet_01v8 L=0.15 W=1 nf=1 m=2
XM2 D9 D9 D9 GND sky130_fd_pr__nfet_01v8 L=0.8 W=1 nf=1 m=4
.ends


* expanding   symbol:  pmos_out2.sym # of pins=6
** sym_path: /home/jihananz/project/mag/pmos_out2.sym
** sch_path: /home/jihananz/project/mag/pmos_out2.sch
.subckt pmos_out2 D5 VDD VIP VIN OUT D8
*.PININFO VIP:I VIN:I D8:B D5:B VDD:B OUT:O
XM6 D8 VIN D5 VDD sky130_fd_pr__pfet_01v8 L=0.5 W=1 nf=1 m=4
XM7 OUT VIP D5 VDD sky130_fd_pr__pfet_01v8 L=0.5 W=1 nf=1 m=4
XM1 D5 D5 D5 VDD sky130_fd_pr__pfet_01v8 L=0.5 W=1 nf=1 m=4
XM2 D8 D8 D8 VDD sky130_fd_pr__pfet_01v8 L=0.5 W=1 nf=1 m=2
XM3 OUT OUT OUT VDD sky130_fd_pr__pfet_01v8 L=0.5 W=1 nf=1 m=2
XM4 D8 D8 D8 VDD sky130_fd_pr__pfet_01v8 L=0.15 W=1 nf=1 m=4
XM5 OUT OUT OUT VDD sky130_fd_pr__pfet_01v8 L=0.15 W=1 nf=1 m=4
.ends

.end
