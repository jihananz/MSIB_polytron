* NGSPICE file created from opampfin.ext - technology: sky130A

.subckt sky130_fd_pr__pfet_01v8_2ZH9AN a_15_n200# a_n15_n226# a_n73_n200# w_n109_n262#
X0 a_15_n200# a_n15_n226# a_n73_n200# w_n109_n262# sky130_fd_pr__pfet_01v8 ad=0.58 pd=4.58 as=0.58 ps=4.58 w=2 l=0.15
.ends

.subckt sky130_fd_pr__pfet_01v8_SDE6B7 a_29_n297# a_n287_n200# a_n229_n297# a_229_n200#
+ a_n29_n200# w_n323_n300#
X0 a_229_n200# a_29_n297# a_n29_n200# w_n323_n300# sky130_fd_pr__pfet_01v8 ad=0.58 pd=4.58 as=0.29 ps=2.29 w=2 l=1
X1 a_n29_n200# a_n229_n297# a_n287_n200# w_n323_n300# sky130_fd_pr__pfet_01v8 ad=0.29 pd=2.29 as=0.58 ps=4.58 w=2 l=1
.ends

.subckt pmos_cs D1 D5 VDD D2
Xsky130_fd_pr__pfet_01v8_2ZH9AN_0 D2 D2 D2 VDD sky130_fd_pr__pfet_01v8_2ZH9AN
Xsky130_fd_pr__pfet_01v8_2ZH9AN_1 D1 D1 D1 VDD sky130_fd_pr__pfet_01v8_2ZH9AN
Xsky130_fd_pr__pfet_01v8_2ZH9AN_2 VDD VDD VDD VDD sky130_fd_pr__pfet_01v8_2ZH9AN
Xsky130_fd_pr__pfet_01v8_2ZH9AN_4 D5 D5 D5 VDD sky130_fd_pr__pfet_01v8_2ZH9AN
Xsky130_fd_pr__pfet_01v8_2ZH9AN_5 VDD VDD VDD VDD sky130_fd_pr__pfet_01v8_2ZH9AN
Xsky130_fd_pr__pfet_01v8_2ZH9AN_7 D2 D2 D2 VDD sky130_fd_pr__pfet_01v8_2ZH9AN
Xsky130_fd_pr__pfet_01v8_2ZH9AN_9 D1 D1 D1 VDD sky130_fd_pr__pfet_01v8_2ZH9AN
Xsky130_fd_pr__pfet_01v8_2ZH9AN_10 D5 D5 D5 VDD sky130_fd_pr__pfet_01v8_2ZH9AN
Xsky130_fd_pr__pfet_01v8_SDE6B7_0 VDD D5 D2 VDD VDD VDD sky130_fd_pr__pfet_01v8_SDE6B7
Xsky130_fd_pr__pfet_01v8_SDE6B7_1 D2 D1 D2 D2 VDD VDD sky130_fd_pr__pfet_01v8_SDE6B7
Xsky130_fd_pr__pfet_01v8_SDE6B7_2 D2 D2 D2 D1 VDD VDD sky130_fd_pr__pfet_01v8_SDE6B7
Xsky130_fd_pr__pfet_01v8_SDE6B7_3 D2 VDD VDD D5 VDD VDD sky130_fd_pr__pfet_01v8_SDE6B7
.ends

.subckt sky130_fd_pr__pfet_01v8_BHRSS5 a_n50_n197# a_50_n100# w_n144_n200# a_n108_n100#
X0 a_50_n100# a_n50_n197# a_n108_n100# w_n144_n200# sky130_fd_pr__pfet_01v8 ad=0.29 pd=2.58 as=0.29 ps=2.58 w=1 l=0.5
.ends

.subckt sky130_fd_pr__pfet_01v8_LA8JHL a_n73_n64# a_n33_n161# w_n109_n164# a_15_n64#
X0 a_15_n64# a_n33_n161# a_n73_n64# w_n109_n164# sky130_fd_pr__pfet_01v8 ad=0.29 pd=2.58 as=0.29 ps=2.58 w=1 l=0.15
.ends

.subckt sky130_fd_pr__pfet_01v8_MA8JHN a_15_n136# a_n33_95# a_n73_n136# w_n109_n198#
X0 a_15_n136# a_n33_95# a_n73_n136# w_n109_n198# sky130_fd_pr__pfet_01v8 ad=0.29 pd=2.58 as=0.29 ps=2.58 w=1 l=0.15
.ends

.subckt pmos_out2 D5 VIN VIP D8 VDD OUT
Xsky130_fd_pr__pfet_01v8_BHRSS5_10 VIN D8 VDD D5 sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_BHRSS5_11 D8 D8 VDD D8 sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_BHRSS5_12 VIN D8 VDD D5 sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_BHRSS5_13 VIP D5 VDD OUT sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_BHRSS5_14 D5 D5 VDD D5 sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_LA8JHL_0 D8 D8 VDD D8 sky130_fd_pr__pfet_01v8_LA8JHL
Xsky130_fd_pr__pfet_01v8_BHRSS5_15 D5 D5 VDD D5 sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_LA8JHL_1 OUT OUT VDD OUT sky130_fd_pr__pfet_01v8_LA8JHL
Xsky130_fd_pr__pfet_01v8_LA8JHL_2 OUT OUT VDD OUT sky130_fd_pr__pfet_01v8_LA8JHL
Xsky130_fd_pr__pfet_01v8_LA8JHL_3 D8 D8 VDD D8 sky130_fd_pr__pfet_01v8_LA8JHL
Xsky130_fd_pr__pfet_01v8_MA8JHN_0 D8 D8 D8 VDD sky130_fd_pr__pfet_01v8_MA8JHN
Xsky130_fd_pr__pfet_01v8_MA8JHN_1 OUT OUT OUT VDD sky130_fd_pr__pfet_01v8_MA8JHN
Xsky130_fd_pr__pfet_01v8_MA8JHN_2 OUT OUT OUT VDD sky130_fd_pr__pfet_01v8_MA8JHN
Xsky130_fd_pr__pfet_01v8_MA8JHN_3 D8 D8 D8 VDD sky130_fd_pr__pfet_01v8_MA8JHN
Xsky130_fd_pr__pfet_01v8_BHRSS5_0 VIP OUT VDD D5 sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_BHRSS5_1 VIN D5 VDD D8 sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_BHRSS5_2 D5 D5 VDD D5 sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_BHRSS5_3 D5 D5 VDD D5 sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_BHRSS5_4 OUT OUT VDD OUT sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_BHRSS5_5 D8 D8 VDD D8 sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_BHRSS5_6 VIN D5 VDD D8 sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_BHRSS5_7 VIP OUT VDD D5 sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_BHRSS5_8 VIP D5 VDD OUT sky130_fd_pr__pfet_01v8_BHRSS5
Xsky130_fd_pr__pfet_01v8_BHRSS5_9 OUT OUT VDD OUT sky130_fd_pr__pfet_01v8_BHRSS5
.ends

.subckt sky130_fd_pr__nfet_01v8_46AAJJ a_100_n200# a_n158_n200# a_n100_n288# VSUBS
X0 a_100_n200# a_n100_n288# a_n158_n200# VSUBS sky130_fd_pr__nfet_01v8 ad=0.58 pd=4.58 as=0.58 ps=4.58 w=2 l=1
.ends

.subckt sky130_fd_pr__nfet_01v8_7QRB7N a_100_n200# a_n158_n200# a_n100_n288# VSUBS
X0 a_100_n200# a_n100_n288# a_n158_n200# VSUBS sky130_fd_pr__nfet_01v8 ad=0.58 pd=4.58 as=0.58 ps=4.58 w=2 l=1
.ends

.subckt sky130_fd_pr__nfet_01v8_TCR5KT a_n33_191# a_n73_n231# a_15_n231# VSUBS
X0 a_15_n231# a_n33_191# a_n73_n231# VSUBS sky130_fd_pr__nfet_01v8 ad=0.58 pd=4.58 as=0.58 ps=4.58 w=2 l=0.15
.ends

.subckt nmosdp D1 RS D4 GND
Xsky130_fd_pr__nfet_01v8_46AAJJ_0 RS D4 D1 GND sky130_fd_pr__nfet_01v8_46AAJJ
Xsky130_fd_pr__nfet_01v8_46AAJJ_1 D1 GND D1 GND sky130_fd_pr__nfet_01v8_46AAJJ
Xsky130_fd_pr__nfet_01v8_46AAJJ_2 D4 RS D1 GND sky130_fd_pr__nfet_01v8_46AAJJ
Xsky130_fd_pr__nfet_01v8_7QRB7N_0 GND D1 D1 GND sky130_fd_pr__nfet_01v8_7QRB7N
Xsky130_fd_pr__nfet_01v8_TCR5KT_0 D1 D1 D1 GND sky130_fd_pr__nfet_01v8_TCR5KT
Xsky130_fd_pr__nfet_01v8_TCR5KT_1 D1 D1 D1 GND sky130_fd_pr__nfet_01v8_TCR5KT
Xsky130_fd_pr__nfet_01v8_TCR5KT_2 D4 D4 D4 GND sky130_fd_pr__nfet_01v8_TCR5KT
Xsky130_fd_pr__nfet_01v8_TCR5KT_3 D4 D4 D4 GND sky130_fd_pr__nfet_01v8_TCR5KT
.ends

.subckt sky130_fd_pr__nfet_01v8_U7AA6P a_n287_n200# a_229_n200# a_29_n288# a_n29_n200#
+ a_n229_n288# VSUBS
X0 a_n29_n200# a_n229_n288# a_n287_n200# VSUBS sky130_fd_pr__nfet_01v8 ad=0.29 pd=2.29 as=0.58 ps=4.58 w=2 l=1
X1 a_229_n200# a_29_n288# a_n29_n200# VSUBS sky130_fd_pr__nfet_01v8 ad=0.58 pd=4.58 as=0.29 ps=2.29 w=2 l=1
.ends

.subckt sky130_fd_pr__nfet_01v8_TC9PLT a_15_n200# a_n15_n226# a_n73_n200# VSUBS
X0 a_15_n200# a_n15_n226# a_n73_n200# VSUBS sky130_fd_pr__nfet_01v8 ad=0.58 pd=4.58 as=0.58 ps=4.58 w=2 l=0.15
.ends

.subckt nmoscs2 GND D8 D9
Xsky130_fd_pr__nfet_01v8_U7AA6P_2 D9 D8 D8 GND D8 GND sky130_fd_pr__nfet_01v8_U7AA6P
Xsky130_fd_pr__nfet_01v8_U7AA6P_3 D9 D8 D8 GND D8 GND sky130_fd_pr__nfet_01v8_U7AA6P
Xsky130_fd_pr__nfet_01v8_TC9PLT_0 D8 D8 D8 GND sky130_fd_pr__nfet_01v8_TC9PLT
Xsky130_fd_pr__nfet_01v8_TC9PLT_1 D8 D8 D8 GND sky130_fd_pr__nfet_01v8_TC9PLT
Xsky130_fd_pr__nfet_01v8_TC9PLT_2 D9 D9 D9 GND sky130_fd_pr__nfet_01v8_TC9PLT
Xsky130_fd_pr__nfet_01v8_TC9PLT_3 D9 D9 D9 GND sky130_fd_pr__nfet_01v8_TC9PLT
Xsky130_fd_pr__nfet_01v8_U7AA6P_0 D8 D9 D8 GND D8 GND sky130_fd_pr__nfet_01v8_U7AA6P
Xsky130_fd_pr__nfet_01v8_U7AA6P_1 D8 D9 D8 GND D8 GND sky130_fd_pr__nfet_01v8_U7AA6P
.ends

.subckt opampfin GND VDD OUT VIN VIP RS D1 D2 D5 D8
Xx1 D1 D5 VDD D2 pmos_cs
Xx2 D5 VIN VIP D8 VDD OUT pmos_out2
Xx3 D1 RS D2 GND nmosdp
Xx4 GND D8 OUT nmoscs2
.ends

