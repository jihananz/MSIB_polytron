v {xschem version=3.4.6RC file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
N 2540 -730 2540 -710 {lab=D5}
N 2540 -730 2630 -730 {lab=D5}
N 2630 -730 2740 -730 {lab=D5}
N 2740 -730 2740 -710 {lab=D5}
N 2720 -680 2740 -680 {lab=VDD}
N 2470 -680 2500 -680 {lab=VIN}
N 2780 -680 2810 -680 {lab=VIP}
N 2540 -680 2610 -680 {lab=VDD}
N 2540 -650 2540 -620 {lab=D8}
N 2610 -680 2630 -680 {lab=VDD}
N 2630 -710 2630 -680 {lab=VDD}
N 2630 -680 2720 -680 {lab=VDD}
N 2740 -650 2740 -620 {lab=OUT}
N 2740 -730 2810 -730 {lab=D5}
N 2740 -620 2810 -620 {lab=OUT}
N 2670 -560 2730 -560 {lab=D5}
N 2730 -560 2730 -500 {lab=D5}
N 2670 -500 2730 -500 {lab=D5}
N 2710 -530 2730 -530 {lab=D5}
N 2590 -550 2590 -530 {lab=VDD}
N 2870 -510 2930 -510 {lab=D8}
N 2910 -540 2930 -540 {lab=D8}
N 2670 -400 2730 -400 {lab=OUT}
N 2710 -430 2730 -430 {lab=OUT}
N 2790 -560 2790 -540 {lab=VDD}
N 2590 -450 2590 -430 {lab=VDD}
N 2910 -420 2970 -420 {lab=D8}
N 2950 -450 2970 -450 {lab=D8}
N 2830 -470 2830 -450 {lab=VDD}
N 2700 -320 2760 -320 {lab=OUT}
N 2740 -350 2760 -350 {lab=OUT}
N 2670 -460 2730 -460 {lab=OUT}
N 2730 -460 2730 -400 {lab=OUT}
N 2700 -380 2760 -380 {lab=OUT}
N 2760 -380 2760 -320 {lab=OUT}
N 2790 -540 2870 -540 {lab=VDD}
N 2870 -570 2930 -570 {lab=D8}
N 2930 -570 2930 -510 {lab=D8}
N 2830 -450 2910 -450 {lab=VDD}
N 2910 -480 2970 -480 {lab=D8}
N 2970 -480 2970 -420 {lab=D8}
N 2620 -370 2620 -350 {lab=VDD}
N 2620 -350 2700 -350 {lab=VDD}
N 2590 -430 2670 -430 {lab=VDD}
N 2590 -530 2670 -530 {lab=VDD}
C {sky130_fd_pr/pfet_01v8.sym} 2520 -680 0 0 {name=M6
L=0.5
W=1
nf=1
mult=4
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {sky130_fd_pr/pfet_01v8.sym} 2760 -680 0 1 {name=M7
L=0.5
W=1
nf=1
mult=4
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {devices/ipin.sym} 2810 -680 2 0 {name=p4 lab=VIP}
C {devices/ipin.sym} 2470 -680 0 0 {name=p5 lab=VIN}
C {devices/iopin.sym} 2540 -620 0 0 {name=p1 lab=D8}
C {devices/iopin.sym} 2810 -730 0 0 {name=p3 lab=D5}
C {devices/iopin.sym} 2630 -710 0 0 {name=p6 lab=VDD}
C {devices/opin.sym} 2810 -620 0 0 {name=p2 lab=OUT}
C {sky130_fd_pr/pfet_01v8.sym} 2690 -530 0 1 {name=M1
L=0.5
W=1
nf=1
mult=4
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {devices/iopin.sym} 2730 -560 0 0 {name=p7 lab=D5}
C {devices/iopin.sym} 2590 -550 0 0 {name=p8 lab=VDD}
C {sky130_fd_pr/pfet_01v8.sym} 2890 -540 0 1 {name=M2
L=0.5
W=1
nf=1
mult=2
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {devices/iopin.sym} 2930 -570 0 0 {name=p9 lab=D8}
C {sky130_fd_pr/pfet_01v8.sym} 2690 -430 0 1 {name=M3
L=0.5
W=1
nf=1
mult=2
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {devices/opin.sym} 2730 -460 0 0 {name=p10 lab=OUT}
C {devices/iopin.sym} 2790 -560 0 0 {name=p11 lab=VDD}
C {devices/iopin.sym} 2590 -450 0 0 {name=p12 lab=VDD}
C {sky130_fd_pr/pfet_01v8.sym} 2930 -450 0 1 {name=M4
L=0.15
W=1
nf=1
mult=4
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {devices/iopin.sym} 2970 -480 0 0 {name=p13 lab=D8}
C {devices/iopin.sym} 2830 -470 0 0 {name=p14 lab=VDD}
C {sky130_fd_pr/pfet_01v8.sym} 2720 -350 0 1 {name=M5
L=0.15
W=1
nf=1
mult=4
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {devices/opin.sym} 2760 -380 0 0 {name=p15 lab=OUT
L=0.15
mult=4}
C {devices/iopin.sym} 2620 -370 0 0 {name=p16 lab=VDD
L=0.15
mult=4}
